package com.hollowveil.entity;

import com.hollowveil.FlashlightHandler;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class WraithEntity extends Monster {
    private boolean scare = false;

    public WraithEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 30.0)
                .add(Attributes.MOVEMENT_SPEED, 0.27)
                .add(Attributes.ATTACK_DAMAGE, 5.0)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.1, false));
        goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 16f));
        goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    public boolean isScare() { return scare; }

    /** ผีที่โผล่มา jumpscare จะไม่โจมตี และหายไปเอง */
    public void setScare(boolean s) {
        scare = s;
        setNoAi(s);
    }

    @Override
    public boolean removeWhenFarAway(double dist) { return scare || super.removeWhenFarAway(dist); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("HvScare", scare);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        scare = tag.getBoolean("HvScare");
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (scare && tickCount > 45) {
            ((ServerLevel) level()).sendParticles(ParticleTypes.SOUL, getX(), getY() + 1, getZ(), 25, 0.3, 0.8, 0.3, 0.02);
            playSound(SoundEvents.ENDERMAN_TELEPORT, 1.0f, 0.5f);
            discard();
            return;
        }
        // ไฟฉายส่องโดน = ช้าลงและเจ็บ
        if (!scare && tickCount % 10 == 0) {
            for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(14))) {
                if (FlashlightHandler.beamHits(p, this, 0.88)) {
                    addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 2, false, false));
                    if (tickCount % 20 == 0) hurt(damageSources().playerAttack(p), 1.0f);
                    break;
                }
            }
        }
    }

    @Override public boolean isSunBurnTick() { return false; }
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.AMBIENT_CAVE.get(); }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.ENDERMAN_SCREAM; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.GHAST_DEATH; }
}
