package com.hollowveil.entity;

import com.hollowveil.FlashlightHandler;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Stalker: ขยับเร็วมากเวลาไม่มีใครมอง แต่แข็งทื่อทันทีถ้าถูกมอง (ไฟฉายส่องแล้วเจ็บด้วย) */
public class StalkerEntity extends Monster {
    public StalkerEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0)
                .add(Attributes.MOVEMENT_SPEED, 0.36)
                .add(Attributes.ATTACK_DAMAGE, 7.0)
                .add(Attributes.FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.7));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || tickCount % 2 != 0) return;
        boolean watched = false;
        for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(40), pl -> !pl.isSpectator())) {
            Vec3 to = position().add(0, getBbHeight() * 0.8, 0).subtract(p.getEyePosition()).normalize();
            if (p.getViewVector(1f).dot(to) > 0.6 && p.hasLineOfSight(this)) {
                watched = true;
                if (tickCount % 20 == 0 && FlashlightHandler.beamHits(p, this, 0.85)) {
                    hurt(damageSources().playerAttack(p), 1.0f);
                }
            }
        }
        if (watched != isNoAi()) setNoAi(watched);
        if (watched) {
            setDeltaMovement(0, getDeltaMovement().y, 0);
            getNavigation().stop();
        }
    }

    @Override public boolean isSunBurnTick() { return false; }
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.AMBIENT_CAVE.get(); }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.ENDERMAN_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENDERMAN_DEATH; }
}
