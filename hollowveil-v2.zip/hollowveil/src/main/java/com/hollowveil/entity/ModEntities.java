package com.hollowveil.entity;

import com.hollowveil.HollowVeil;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, HollowVeil.MODID);

    public static final RegistryObject<EntityType<WraithEntity>> WRAITH = ENTITIES.register("wraith",
            () -> EntityType.Builder.of(WraithEntity::new, MobCategory.MONSTER)
                    .sized(0.7f, 2.4f).clientTrackingRange(8)
                    .build(new ResourceLocation(HollowVeil.MODID, "wraith").toString()));

    public static final RegistryObject<EntityType<StalkerEntity>> STALKER = ENTITIES.register("stalker",
            () -> EntityType.Builder.of(StalkerEntity::new, MobCategory.MONSTER)
                    .sized(0.6f, 2.8f).clientTrackingRange(8)
                    .build(new ResourceLocation(HollowVeil.MODID, "stalker").toString()));
}
