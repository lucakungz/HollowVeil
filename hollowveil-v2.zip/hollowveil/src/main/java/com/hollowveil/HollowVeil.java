package com.hollowveil;

import com.hollowveil.block.ModBlocks;
import com.hollowveil.entity.ModEntities;
import com.hollowveil.item.ModItems;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(HollowVeil.MODID)
public class HollowVeil {
    public static final String MODID = "hollowveil";

    public HollowVeil() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, HVConfig.SPEC);
        MinecraftForge.EVENT_BUS.register(new HorrorEvents());
    }
}
