package com.hollowveil.block;

import com.hollowveil.HorrorEvents;
import com.hollowveil.item.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** หลุมศพ: คลิกขวาเพื่อค้น ได้ของ... หรือปลุกอะไรบางอย่าง */
public class GraveBlock extends Block {
    public GraveBlock(Properties p) { super(p); }

    @Override
    public InteractionResult use(BlockState st, Level level, BlockPos pos, Player pl, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(level instanceof ServerLevel sl) || !(pl instanceof ServerPlayer sp)) return InteractionResult.PASS;
        RandomSource r = sl.random;
        int roll = r.nextInt(100);
        sl.setBlock(pos, Blocks.COARSE_DIRT.defaultBlockState(), 3);
        sl.playSound(null, pos, SoundEvents.GRAVEL_BREAK, SoundSource.BLOCKS, 1f, 0.6f);
        if (roll < 25) popResource(sl, pos.above(), new ItemStack(Items.BONE, 1 + r.nextInt(3)));
        else if (roll < 50) popResource(sl, pos.above(), new ItemStack(ModItems.DIARY_PAGE.get()));
        else if (roll < 70) popResource(sl, pos.above(), new ItemStack(ModItems.BATTERY.get()));
        else if (roll < 85) popResource(sl, pos.above(), new ItemStack(Items.GOLD_NUGGET, 2 + r.nextInt(4)));
        else {
            HorrorEvents.spawnWraith(sl, pos.above());
            HorrorEvents.scare(sp, sl);
        }
        return InteractionResult.CONSUME;
    }
}
