package com.hollowveil.compat;

import com.hollowveil.HorrorEvents;
import de.maxhenkel.voicechat.api.ForgeVoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MicrophonePacketEvent;
import net.minecraft.server.level.ServerPlayer;

/** โหลดเฉพาะเมื่อมี Simple Voice Chat: พูดใกล้ผี = ผีได้ยินและวิ่งมาหา (กระซิบไม่ดึงดูด) */
@ForgeVoicechatPlugin
public class HollowVoicechatPlugin implements VoicechatPlugin {
    @Override
    public String getPluginId() { return "hollowveil"; }

    @Override
    public void registerEvents(EventRegistration reg) {
        reg.registerEvent(MicrophonePacketEvent.class, this::onMic);
    }

    private void onMic(MicrophonePacketEvent e) {
        VoicechatConnection c = e.getSenderConnection();
        if (c == null || e.getPacket().isWhispering()) return;
        Object o = c.getPlayer().getPlayer();
        if (o instanceof ServerPlayer sp) HorrorEvents.heardNoise(sp);
    }
}
