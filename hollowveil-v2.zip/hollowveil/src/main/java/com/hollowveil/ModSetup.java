package com.hollowveil;

import com.hollowveil.entity.ModEntities;
import com.hollowveil.entity.StalkerEntity;
import com.hollowveil.entity.WraithEntity;
import com.hollowveil.item.ModItems;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = HollowVeil.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModSetup {
    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent ev) {
        ev.put(ModEntities.WRAITH.get(), WraithEntity.createAttributes().build());
        ev.put(ModEntities.STALKER.get(), StalkerEntity.createAttributes().build());
    }

    @SubscribeEvent
    public static void spawns(SpawnPlacementRegisterEvent ev) {
        // จำกัดจำนวนมอนในรัศมี 48 บล็อก กัน lag
        ev.register(ModEntities.WRAITH.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, lvl, reason, pos, rand) -> Monster.checkMonsterSpawnRules(type, lvl, reason, pos, rand)
                        && lvl.getEntitiesOfClass(WraithEntity.class, new AABB(pos).inflate(48)).size() < HVConfig.MAX_NEARBY.get(),
                SpawnPlacementRegisterEvent.Operation.OR);
        ev.register(ModEntities.STALKER.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, lvl, reason, pos, rand) -> Monster.checkMonsterSpawnRules(type, lvl, reason, pos, rand)
                        && lvl.getEntitiesOfClass(StalkerEntity.class, new AABB(pos).inflate(64)).size() < 2,
                SpawnPlacementRegisterEvent.Operation.OR);
    }

    @SubscribeEvent
    public static void tabs(BuildCreativeModeTabContentsEvent ev) {
        if (ev.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            ev.accept(ModItems.MOURNING_BELL);
            ev.accept(ModItems.FLASHLIGHT);
            ev.accept(ModItems.BATTERY);
            ev.accept(ModItems.DIARY_PAGE);
        }
        if (ev.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) ev.accept(ModItems.GRAVE);
        if (ev.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            ev.accept(ModItems.WRAITH_SPAWN_EGG);
            ev.accept(ModItems.STALKER_SPAWN_EGG);
        }
    }
}
