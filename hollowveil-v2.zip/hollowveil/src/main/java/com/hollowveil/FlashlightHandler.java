package com.hollowveil;

import com.hollowveil.item.FlashlightItem;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** ไฟฉาย: วาง "light block" ชั่วคราวตรงจุดที่มอง ย้ายทุกไม่กี่ tick (เบา ไม่ต้องใช้ shader) */
public class FlashlightHandler {
    private record LightPos(ResourceKey<Level> dim, BlockPos pos) {}
    private static final Map<UUID, LightPos> LIGHTS = new HashMap<>();

    public static ItemStack litStack(Player p) {
        for (InteractionHand h : InteractionHand.values()) {
            ItemStack s = p.getItemInHand(h);
            if (s.getItem() instanceof FlashlightItem && FlashlightItem.isOn(s)) return s;
        }
        return ItemStack.EMPTY;
    }

    public static boolean isLit(Player p) { return !litStack(p).isEmpty(); }

    /** ไฟฉายของผู้เล่นส่องโดน entity นั้นอยู่หรือไม่ */
    public static boolean beamHits(Player p, Entity target, double minDot) {
        if (!isLit(p) || p.distanceToSqr(target) > 14 * 14) return false;
        Vec3 to = target.position().add(0, target.getBbHeight() * 0.5, 0).subtract(p.getEyePosition()).normalize();
        return p.getViewVector(1f).dot(to) > minDot && p.hasLineOfSight(target);
    }

    public static void tick(ServerPlayer p) {
        ItemStack s = litStack(p);
        if (s.isEmpty()) { clear(p); return; }
        if (!p.isCreative() && p.tickCount % 20 == 0) {
            if (s.getDamageValue() >= s.getMaxDamage() - 1) {
                s.getOrCreateTag().putBoolean("on", false);
                p.displayClientMessage(Component.literal("§cแบตเตอรี่ไฟฉายหมด!"), true);
                clear(p);
                return;
            }
            s.setDamageValue(s.getDamageValue() + 1);
        }
        if (!HVConfig.FLASHLIGHT_LIGHT.get() || p.tickCount % HVConfig.LIGHT_INTERVAL.get() != 0) return;

        ServerLevel lvl = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        HitResult hit = p.pick(14.0, 1.0f, false);
        Vec3 target = hit.getType() == HitResult.Type.MISS ? eye.add(look.scale(10)) : hit.getLocation().subtract(look.scale(0.6));
        BlockPos pos = BlockPos.containing(target);
        if (!lvl.isLoaded(pos)) return;
        if (!lvl.getBlockState(pos).isAir()) {
            pos = BlockPos.containing(eye);
            if (!lvl.getBlockState(pos).isAir()) return;
        }
        LightPos old = LIGHTS.get(p.getUUID());
        if (old != null && old.dim == lvl.dimension() && old.pos.equals(pos)) return;
        clear(p);
        lvl.setBlock(pos, Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, 13), 2);
        LIGHTS.put(p.getUUID(), new LightPos(lvl.dimension(), pos));
    }

    public static void clear(ServerPlayer p) {
        LightPos old = LIGHTS.remove(p.getUUID());
        if (old == null) return;
        ServerLevel lvl = p.server.getLevel(old.dim);
        if (lvl != null && lvl.isLoaded(old.pos) && lvl.getBlockState(old.pos).is(Blocks.LIGHT)) {
            lvl.setBlock(old.pos, Blocks.AIR.defaultBlockState(), 2);
        }
    }

    public static void clearAll(net.minecraft.server.MinecraftServer server) {
        for (LightPos lp : LIGHTS.values()) {
            ServerLevel lvl = server.getLevel(lp.dim);
            if (lvl != null && lvl.isLoaded(lp.pos) && lvl.getBlockState(lp.pos).is(Blocks.LIGHT)) {
                lvl.setBlock(lp.pos, Blocks.AIR.defaultBlockState(), 2);
            }
        }
        LIGHTS.clear();
    }
}
