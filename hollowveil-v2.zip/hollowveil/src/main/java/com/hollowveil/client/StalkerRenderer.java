package com.hollowveil.client;

import com.hollowveil.HollowVeil;
import com.hollowveil.entity.StalkerEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class StalkerRenderer extends MobRenderer<StalkerEntity, StalkerModel> {
    private static final ResourceLocation TEX = new ResourceLocation(HollowVeil.MODID, "textures/entity/stalker.png");

    public StalkerRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new StalkerModel(ctx.bakeLayer(StalkerModel.LAYER)), 0.3f);
    }

    @Override
    public ResourceLocation getTextureLocation(StalkerEntity e) { return TEX; }
}
