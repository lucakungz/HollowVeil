package com.hollowveil.client;

import com.hollowveil.HollowVeil;
import com.hollowveil.entity.WraithEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;

/** โมเดล 3D ของผี: หัวโล้น ตัวยาวเหมือนชุดขาด แขนยาวเกือบถึงพื้น */
public class WraithModel extends EntityModel<WraithEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(HollowVeil.MODID, "wraith"), "main");
    private final ModelPart root, head, rightArm, leftArm;

    public WraithModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = mesh.getRoot();
        p.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-4f, -10f, -4f, 8f, 10f, 8f), PartPose.offset(0f, 2f, 0f));
        p.addOrReplaceChild("body", CubeListBuilder.create().texOffs(32, 0)
                .addBox(-5f, 0f, -3f, 10f, 22f, 6f), PartPose.offset(0f, 2f, 0f));
        p.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(0, 32)
                .addBox(-1.5f, 0f, -1.5f, 3f, 22f, 3f), PartPose.offset(-6.5f, 4f, 0f));
        p.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(16, 32)
                .addBox(-1.5f, 0f, -1.5f, 3f, 22f, 3f), PartPose.offset(6.5f, 4f, 0f));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(WraithEntity e, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        head.yRot = yaw * ((float) Math.PI / 180f);
        head.xRot = pitch * ((float) Math.PI / 180f) + 0.15f;
        head.zRot = (float) Math.sin(age * 0.07f) * 0.08f; // เอียงคอสั่นๆ
        rightArm.xRot = -1.35f + (float) Math.sin(age * 0.09f) * 0.12f;
        leftArm.xRot = -1.35f - (float) Math.sin(age * 0.09f) * 0.12f;
        rightArm.zRot = 0.08f;
        leftArm.zRot = -0.08f;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
