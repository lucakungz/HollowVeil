package com.hollowveil.client;

import com.hollowveil.HollowVeil;
import com.hollowveil.entity.WraithEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class WraithRenderer extends MobRenderer<WraithEntity, WraithModel> {
    private static final ResourceLocation TEX = new ResourceLocation(HollowVeil.MODID, "textures/entity/wraith.png");

    public WraithRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new WraithModel(ctx.bakeLayer(WraithModel.LAYER)), 0.4f);
    }

    @Override
    public ResourceLocation getTextureLocation(WraithEntity e) { return TEX; }
}
