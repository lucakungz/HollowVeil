package com.hollowveil.client;

import com.hollowveil.HollowVeil;
import com.hollowveil.entity.StalkerEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;

/** Stalker: ตัวสูง 2.8 บล็อก แขนขายาวผิดสัดส่วน หัวเล็กเอียง */
public class StalkerModel extends EntityModel<StalkerEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(HollowVeil.MODID, "stalker"), "main");
    private final ModelPart root, head, rightArm, leftArm, rightLeg, leftLeg;

    public StalkerModel(ModelPart root) {
        this.root = root;
        head = root.getChild("head");
        rightArm = root.getChild("right_arm");
        leftArm = root.getChild("left_arm");
        rightLeg = root.getChild("right_leg");
        leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = mesh.getRoot();
        p.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-3f, -8f, -3f, 6f, 8f, 6f), PartPose.offset(0f, -13f, 0f));
        p.addOrReplaceChild("body", CubeListBuilder.create().texOffs(24, 0)
                .addBox(-3f, 0f, -2f, 6f, 16f, 4f), PartPose.offset(0f, -13f, 0f));
        p.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(0, 22)
                .addBox(-1f, 0f, -1f, 2f, 24f, 2f), PartPose.offset(-4f, -12f, 0f));
        p.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(8, 22)
                .addBox(-1f, 0f, -1f, 2f, 24f, 2f), PartPose.offset(4f, -12f, 0f));
        p.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(44, 0)
                .addBox(-1f, 0f, -1f, 2f, 21f, 2f), PartPose.offset(-2f, 3f, 0f));
        p.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(52, 0)
                .addBox(-1f, 0f, -1f, 2f, 21f, 2f), PartPose.offset(2f, 3f, 0f));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(StalkerEntity e, float limb, float limbAmt, float age, float yaw, float pitch) {
        head.yRot = yaw * ((float) Math.PI / 180f);
        head.xRot = pitch * ((float) Math.PI / 180f);
        head.zRot = 0.35f; // เอียงคอผิดธรรมชาติ
        rightLeg.xRot = (float) Math.cos(limb * 0.6662f) * 1.4f * limbAmt;
        leftLeg.xRot = (float) Math.cos(limb * 0.6662f + Math.PI) * 1.4f * limbAmt;
        rightArm.xRot = (float) Math.cos(limb * 0.6662f + Math.PI) * 1.2f * limbAmt;
        leftArm.xRot = (float) Math.cos(limb * 0.6662f) * 1.2f * limbAmt;
        rightArm.zRot = 0.05f + (float) Math.sin(age * 0.05f) * 0.03f;
        leftArm.zRot = -0.05f - (float) Math.sin(age * 0.05f) * 0.03f;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
