package com.hollowveil.client;

import com.hollowveil.HollowVeil;
import com.hollowveil.entity.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = HollowVeil.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(WraithModel.LAYER, WraithModel::createBodyLayer);
        e.registerLayerDefinition(StalkerModel.LAYER, StalkerModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.WRAITH.get(), WraithRenderer::new);
        e.registerEntityRenderer(ModEntities.STALKER.get(), StalkerRenderer::new);
    }
}
