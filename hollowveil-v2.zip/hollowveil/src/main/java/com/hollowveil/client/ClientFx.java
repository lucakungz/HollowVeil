package com.hollowveil.client;

import com.hollowveil.HollowVeil;
import com.hollowveil.HorrorEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** หมอกหนาในมิติ The Hollow (ยังช่วยลดภาระการเรนเดอร์บนมือถือด้วย) */
@Mod.EventBusSubscriber(modid = HollowVeil.MODID, value = Dist.CLIENT)
public class ClientFx {
    @SubscribeEvent
    public static void fog(ViewportEvent.RenderFog e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.level.dimension() != HorrorEvents.HOLLOW) return;
        if (e.getMode() != FogRenderer.FogMode.FOG_TERRAIN) return;
        e.setNearPlaneDistance(0f);
        e.setFarPlaneDistance(48f);
        e.setCanceled(true);
    }
}
