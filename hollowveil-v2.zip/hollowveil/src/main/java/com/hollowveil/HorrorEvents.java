package com.hollowveil;

import com.hollowveil.entity.ModEntities;
import com.hollowveil.entity.StalkerEntity;
import com.hollowveil.entity.WraithEntity;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class HorrorEvents {
    public static final ResourceKey<Level> HOLLOW =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(HollowVeil.MODID, "the_hollow"));
    private static final Map<UUID, Long> LAST_NOISE = new ConcurrentHashMap<>();

    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        FlashlightHandler.tick(p);
        if (p.level().dimension() != HOLLOW || p.isSpectator()) return;
        ServerLevel lvl = p.serverLevel();
        RandomSource r = p.getRandom();

        if (r.nextInt(HVConfig.AMBIENT_CHANCE_TICKS.get()) == 0) ambient(p, r);

        // ความมืดวูบเบาๆ ถ้าไม่ได้เปิดไฟฉาย
        if (HVConfig.DARK_PULSES.get() && r.nextInt(2400) == 0 && !FlashlightHandler.isLit(p)) {
            p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 160, 0, false, false));
        }

        if (HVConfig.JUMPSCARES.get()) {
            CompoundTag d = p.getPersistentData();
            long now = lvl.getGameTime();
            if (now >= d.getLong("hv_next_scare") && r.nextInt(HVConfig.SCARE_CHANCE_TICKS.get()) == 0) {
                scare(p, lvl);
                d.putLong("hv_next_scare", now + HVConfig.SCARE_COOLDOWN_SEC.get() * 20L + r.nextInt(3000));
            }
        }
    }

    @SubscribeEvent
    public void onClone(PlayerEvent.Clone e) {
        e.getEntity().getPersistentData().merge(e.getOriginal().getPersistentData());
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            FlashlightHandler.clear(p);
            LAST_NOISE.remove(p.getUUID());
        }
    }

    @SubscribeEvent
    public void onStopping(ServerStoppingEvent e) {
        FlashlightHandler.clearAll(e.getServer());
        LAST_NOISE.clear();
    }

    @SubscribeEvent
    public void commands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("hollowveil").requires(s -> s.hasPermission(2))
                .then(Commands.literal("scare").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    scare(p, p.serverLevel());
                    return 1;
                }))
                .then(Commands.literal("wraith").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    spawnWraith(p.serverLevel(), p.blockPosition().offset(3, 0, 0));
                    return 1;
                }))
                .then(Commands.literal("stalker").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    StalkerEntity s = ModEntities.STALKER.get().create(p.serverLevel());
                    if (s != null) {
                        s.moveTo(p.getX() + 8, p.getY(), p.getZ(), 0, 0);
                        p.serverLevel().addFreshEntity(s);
                    }
                    return 1;
                }))
                .then(Commands.literal("story").then(Commands.argument("page", IntegerArgumentType.integer(0, 8)).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    p.getPersistentData().putInt("hv_story", IntegerArgumentType.getInteger(c, "page"));
                    c.getSource().sendSuccess(() -> Component.literal("ตั้งความคืบหน้าเนื้อเรื่อง"), false);
                    return 1;
                }))));
    }

    /** เสียงจากไมค์ Simple Voice Chat (เรียกจาก thread ของ voicechat) */
    public static void heardNoise(ServerPlayer p) {
        if (!HVConfig.VOICE_ATTRACTS.get()) return;
        long now = System.currentTimeMillis();
        Long last = LAST_NOISE.get(p.getUUID());
        if (last != null && now - last < 1500) return;
        LAST_NOISE.put(p.getUUID(), now);
        p.server.execute(() -> {
            if (p.level().dimension() != HOLLOW || p.isSpectator()) return;
            AABB box = p.getBoundingBox().inflate(32);
            for (Mob m : p.serverLevel().getEntitiesOfClass(Mob.class, box,
                    m -> m instanceof StalkerEntity || (m instanceof WraithEntity w && !w.isScare()))) {
                m.setTarget(p);
            }
        });
    }

    public static void spawnWraith(ServerLevel lvl, BlockPos pos) {
        WraithEntity w = ModEntities.WRAITH.get().create(lvl);
        if (w != null) {
            w.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, lvl.random.nextFloat() * 360f, 0f);
            lvl.addFreshEntity(w);
        }
    }

    /** ส่งเสียงให้ผู้เล่นคนเดียวได้ยิน (multiplayer: ไม่รบกวนคนอื่น) */
    public static void soundTo(ServerPlayer p, SoundEvent s, SoundSource src, double x, double y, double z, float vol, float pitch) {
        p.connection.send(new ClientboundSoundPacket(BuiltInRegistries.SOUND_EVENT.wrapAsHolder(s), src, x, y, z, vol, pitch, p.getRandom().nextLong()));
    }

    private static void ambient(ServerPlayer p, RandomSource r) {
        SoundEvent[] pool = {
            SoundEvents.AMBIENT_CAVE.get(), SoundEvents.GHAST_AMBIENT, SoundEvents.WITCH_AMBIENT,
            SoundEvents.VILLAGER_NO, SoundEvents.ENDERMAN_STARE, SoundEvents.BELL_BLOCK,
            SoundEvents.WARDEN_NEARBY_CLOSER, SoundEvents.WARDEN_HEARTBEAT
        };
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = 7 + r.nextInt(8);
        soundTo(p, pool[r.nextInt(pool.length)], SoundSource.AMBIENT,
                p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist, 1.2f, 0.5f + r.nextFloat() * 0.4f);
    }

    public static void scare(ServerPlayer p, ServerLevel lvl) {
        Vec3 look = p.getLookAngle().multiply(1, 0, 1);
        if (look.lengthSqr() < 1.0E-4) look = new Vec3(0, 0, 1);
        look = look.normalize();
        WraithEntity w = ModEntities.WRAITH.get().create(lvl);
        if (w != null) {
            for (double dist : new double[]{2.4, 1.8, 1.2}) {
                Vec3 pos = p.position().add(look.scale(dist));
                w.moveTo(pos.x, pos.y, pos.z, p.getYRot() + 180f, 0f);
                if (lvl.noCollision(w)) {
                    w.setScare(true);
                    lvl.addFreshEntity(w);
                    break;
                }
            }
        }
        soundTo(p, SoundEvents.GHAST_SCREAM, SoundSource.HOSTILE, p.getX(), p.getY(), p.getZ(), 2.0f, 0.5f);
        soundTo(p, SoundEvents.ENDERMAN_SCREAM, SoundSource.HOSTILE, p.getX(), p.getY(), p.getZ(), 2.0f, 0.4f);
        p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 50, 0, false, false));
    }
}
