package com.hollowveil;

import net.minecraftforge.common.ForgeConfigSpec;

/** ปรับค่าได้ที่ config/hollowveil-common.toml  (ลด lag บนมือถือได้ที่นี่) */
public class HVConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue JUMPSCARES, DARK_PULSES, FLASHLIGHT_LIGHT, VOICE_ATTRACTS;
    public static final ForgeConfigSpec.IntValue SCARE_COOLDOWN_SEC, SCARE_CHANCE_TICKS, AMBIENT_CHANCE_TICKS, MAX_NEARBY, LIGHT_INTERVAL;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("horror");
        JUMPSCARES = b.comment("เปิด jumpscare").define("jumpscares", true);
        SCARE_COOLDOWN_SEC = b.comment("หน่วงเวลาขั้นต่ำระหว่าง jumpscare (วินาที)").defineInRange("scareCooldownSeconds", 300, 30, 36000);
        SCARE_CHANCE_TICKS = b.comment("ยิ่งมากยิ่งเกิดน้อย (1 ใน N ต่อ tick หลังพ้น cooldown)").defineInRange("scareChanceTicks", 6000, 200, 200000);
        AMBIENT_CHANCE_TICKS = b.comment("ความถี่เสียงหลอน (1 ใน N ต่อ tick)").defineInRange("ambientChanceTicks", 1500, 100, 200000);
        DARK_PULSES = b.comment("ความมืดวูบเป็นพักๆ ถ้าไม่ได้ถือไฟฉายเปิดอยู่").define("darkPulses", true);
        MAX_NEARBY = b.comment("จำนวนผีสูงสุดในรัศมี 48 บล็อก (ลดเพื่อลด lag)").defineInRange("maxMobsNearby", 4, 1, 20);
        b.pop();
        b.push("flashlight");
        FLASHLIGHT_LIGHT = b.comment("ไฟฉายสร้างแสงจริง (ปิดถ้าเครื่องอืด)").define("flashlightLight", true);
        LIGHT_INTERVAL = b.comment("อัปเดตแสงทุกกี่ tick (มากขึ้น = เบาขึ้น)").defineInRange("lightUpdateTicks", 5, 2, 40);
        b.pop();
        b.push("voicechat");
        VOICE_ATTRACTS = b.comment("เสียงพูดผ่าน Simple Voice Chat ดึงดูดผี (ใช้ได้เมื่อมี voicechat)").define("voiceAttractsGhosts", true);
        b.pop();
        SPEC = b.build();
    }
}
