package com.hollowveil.item;

import com.hollowveil.HorrorEvents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** หน้าไดอารี่ แต่ละหน้าที่อ่านจะเปิดเนื้อเรื่องต่อไปเรื่อยๆ */
public class DiaryPageItem extends Item {
    public static final String[] STORY = {
        "§7[หน้า 1] วันที่ 3 — หมู่บ้านบ้านโหลงเงียบผิดปกติ หมาไม่เห่า ไก่ไม่ขัน มีแต่เสียงระฆังที่ศาลาริมน้ำ ตีเองตอนตีสาม",
        "§7[หน้า 2] ผู้เฒ่าบอกว่าระฆังนั้นเรียกว่า 'ระฆังไว้อาลัย' ใช้ตีเรียกวิญญาณมาลาคนตาย แต่ห้ามตีเกินสามครั้ง",
        "§7[หน้า 3] คืนนี้ฉันเห็นคนยืนอยู่ริมบึง หน้าขาว ตาเป็นรู ฉันเรียกเขา เขาไม่หันมา แต่ฉันได้ยินเสียงฉันเองตอบกลับมาจากข้างหลัง",
        "§7[หน้า 4] วันที่ 9 — คนหายไปแล้วห้าคน ทุกบ้านเหลือแต่รองเท้าไว้หน้าประตู หันเข้าหาบ้านเสมอ",
        "§7[หน้า 5] มิติของพวกมันคือ 'The Hollow' ที่ที่ไม่มีเช้า พวกมันไม่ได้อยากฆ่าเรา พวกมันแค่เหงา และอยากให้เราอยู่ด้วย",
        "§7[หน้า 6] ถ้าได้ยินเสียงคนเรียกชื่อจากด้านหลัง อย่าหัน อย่าตอบ และอย่าวิ่ง ... พวกมันชอบคนที่วิ่ง",
        "§7[หน้า 7] ฉันรู้แล้วว่าใครตีระฆังครั้งแรก มันไม่ใช่ผี ... ลายมือหน้าสุดท้ายในสมุดเล่มนี้ ใกล้เคียงกับลายมือฉันเกินไป",
        "§4[หน้าสุดท้าย] §cลายมือในหน้านี้เป็นของคุณ ... คุณคือคนที่ตีระฆังครั้งแรก  แล้วเขาก็อยู่ข้างหลังคุณมาตลอด"
    };

    public DiaryPageItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        CompoundTag d = sp.getPersistentData();
        int cur = d.getInt("hv_story");
        int n = Math.min(cur, STORY.length - 1);
        sp.sendSystemMessage(Component.literal(STORY[n]));
        level.playSound(null, sp.blockPosition(), SoundEvents.BOOK_PAGE_TURN, SoundSource.PLAYERS, 1f, 0.7f);
        if (cur < STORY.length) d.putInt("hv_story", cur + 1);
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        if (cur == STORY.length - 1) HorrorEvents.scare(sp, sp.serverLevel()); // หน้าสุดท้าย = jumpscare ครั้งเดียว
        return InteractionResultHolder.sidedSuccess(stack, false);
    }
}
