package com.hollowveil.item;

import com.hollowveil.HollowVeil;
import com.hollowveil.block.ModBlocks;
import com.hollowveil.entity.ModEntities;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, HollowVeil.MODID);

    public static final RegistryObject<Item> MOURNING_BELL = ITEMS.register("mourning_bell",
            () -> new MourningBellItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> DIARY_PAGE = ITEMS.register("diary_page",
            () -> new DiaryPageItem(new Item.Properties()));
    public static final RegistryObject<Item> FLASHLIGHT = ITEMS.register("flashlight",
            () -> new FlashlightItem(new Item.Properties().stacksTo(1).durability(900)));
    public static final RegistryObject<Item> BATTERY = ITEMS.register("battery",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> GRAVE = ITEMS.register("grave",
            () -> new BlockItem(ModBlocks.GRAVE.get(), new Item.Properties()));
    public static final RegistryObject<Item> WRAITH_SPAWN_EGG = ITEMS.register("wraith_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.WRAITH, 0x8a97a3, 0x000000, new Item.Properties()));
    public static final RegistryObject<Item> STALKER_SPAWN_EGG = ITEMS.register("stalker_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.STALKER, 0x2a2830, 0xf0f0e0, new Item.Properties()));
}
