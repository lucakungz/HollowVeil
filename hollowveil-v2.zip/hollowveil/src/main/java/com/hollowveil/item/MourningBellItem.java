package com.hollowveil.item;

import com.hollowveil.HorrorEvents;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

/** ตีระฆัง = ไปมิติ The Hollow / ตีอีกครั้ง = กลับบ้าน */
public class MourningBellItem extends Item {
    public MourningBellItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        level.playSound(null, sp.blockPosition(), SoundEvents.BELL_BLOCK, SoundSource.PLAYERS, 3f, 0.4f);
        CompoundTag d = sp.getPersistentData();

        if (level.dimension() != HorrorEvents.HOLLOW) {
            ServerLevel target = sp.server.getLevel(HorrorEvents.HOLLOW);
            if (target == null) return InteractionResultHolder.fail(stack);
            d.putDouble("hv_x", sp.getX());
            d.putDouble("hv_y", sp.getY());
            d.putDouble("hv_z", sp.getZ());
            d.putString("hv_dim", level.dimension().location().toString());
            int x = sp.getBlockX(), z = sp.getBlockZ();
            int y = target.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) + 1;
            sp.teleportTo(target, x + 0.5, y, z + 0.5, sp.getYRot(), 0);
            d.putLong("hv_next_scare", target.getGameTime() + 2400); // เข้ามาใหม่ๆ ยังไม่หลอก
            sp.connection.send(new ClientboundSetTitlesAnimationPacket(20, 80, 30));
            sp.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal("§7อย่าตอบเสียงที่เรียกชื่อคุณ")));
            sp.connection.send(new ClientboundSetTitleTextPacket(Component.literal("§4THE HOLLOW")));
        } else {
            ServerLevel back = d.contains("hv_dim")
                    ? sp.server.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(d.getString("hv_dim"))))
                    : sp.server.overworld();
            if (back == null || back.dimension() == HorrorEvents.HOLLOW) back = sp.server.overworld();
            double x = d.contains("hv_x") ? d.getDouble("hv_x") : back.getSharedSpawnPos().getX();
            double y = d.contains("hv_y") ? d.getDouble("hv_y") : back.getSharedSpawnPos().getY();
            double z = d.contains("hv_z") ? d.getDouble("hv_z") : back.getSharedSpawnPos().getZ();
            sp.teleportTo(back, x, y, z, sp.getYRot(), 0);
        }
        sp.getCooldowns().addCooldown(this, 100);
        return InteractionResultHolder.sidedSuccess(stack, false);
    }
}
