package com.hollowveil.item;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** ไฟฉาย: คลิกขวาเปิด/ปิด (เรืองแสงเมื่อเปิด) แบตหมดซ่อมด้วย Battery ที่ anvil */
public class FlashlightItem extends Item {
    public FlashlightItem(Properties p) { super(p); }

    public static boolean isOn(ItemStack s) {
        return s.hasTag() && s.getTag().getBoolean("on");
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            boolean turnOn = !isOn(stack);
            if (turnOn && stack.getDamageValue() >= stack.getMaxDamage() - 1) {
                player.displayClientMessage(Component.literal("§cแบตหมด! ซ่อมด้วย Battery ที่ anvil"), true);
                return InteractionResultHolder.fail(stack);
            }
            stack.getOrCreateTag().putBoolean("on", turnOn);
            level.playSound(null, player.blockPosition(), SoundEvents.LEVER_CLICK, SoundSource.PLAYERS, 0.8f, turnOn ? 1.4f : 0.9f);
            player.displayClientMessage(Component.literal(turnOn ? "§eไฟฉาย: เปิด" : "§7ไฟฉาย: ปิด"), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public boolean isFoil(ItemStack stack) { return isOn(stack); }

    @Override
    public boolean isValidRepairItem(ItemStack stack, ItemStack repair) {
        return repair.is(ModItems.BATTERY.get());
    }
}
