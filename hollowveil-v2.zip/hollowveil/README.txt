HOLLOW VEIL v1.0 - Forge 1.20.1 horror mod
เล่น multiplayer ได้ (jumpscare/เสียงส่งเฉพาะคนที่โดน) | รองรับ Simple Voice Chat (ไม่บังคับ)
สร้างไฟล์ .jar: ดูวิธีใน build.yml (GitHub Actions) หรือ  gradle build  (JDK 17, Gradle 8.1.1)
Config: config/hollowveil-common.toml
คำสั่งทดสอบ (OP): /hollowveil scare | wraith | stalker | story <0-8>
